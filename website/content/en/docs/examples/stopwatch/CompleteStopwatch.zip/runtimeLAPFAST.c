/* used C headers */
#include <math.h>
#include <stdio.h>
#include <windows.h>
#include <winuser.h>
#pragma comment(lib, "User32.lib")

/* blech types */
#include "blech.h"
#include "blech/stopwatchLAPFAST.c"

#define ONE (unsigned short)1
#define S_KEY 0x53
#define R_KEY 0x52

HANDLE hConsole;
double fqAsMs;

/* Implementation of blech defined stubs */
void showConsole (const struct blc_stopwatchLAPFAST_Display *const blc_this)
{
    COORD pos = {1, 1};
    SetConsoleCursorPosition(hConsole, pos);
    printf ("%ld\t%ld\t%ld\t", blc_this->minutes, blc_this->seconds, blc_this->hundredth);
}

// Pauses for a specified number of milliseconds.
// adapted from https://stackoverflow.com/questions/15720542/measure-execution-time-in-c-on-windows
void do_sleep( LARGE_INTEGER start )
{
    static LARGE_INTEGER end;
    static double interval;
    do {
        QueryPerformanceCounter(&end);    
        interval = (double) (end.QuadPart - start.QuadPart) / fqAsMs;
    } while (interval < 10);
}

/*
** the test main loop
*/
int main(void) {
    /* set up console handler and cursor */
    CONSOLE_CURSOR_INFO curInfo = {.dwSize = 1, .bVisible = 0};
    hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorInfo(hConsole,&curInfo);

    /* write the min:sec:cs once as this does not change */
    COORD pos = {1, 2};
    SetConsoleCursorPosition(hConsole, pos);
    printf ("min\tsec\tcs");

    /* set up blech program */
    blc_blech_stopwatchLAPFAST_init();
    SHORT sKey = GetAsyncKeyState(S_KEY); 
    SHORT rKey = GetAsyncKeyState(R_KEY);

    /* initialise performance counters for time measurement */
    LARGE_INTEGER frequency;
    LARGE_INTEGER start;
    QueryPerformanceCounter(&start);
    QueryPerformanceFrequency(&frequency);
    fqAsMs = frequency.QuadPart / 1000.0;
    
    while( 1 )
    {
        do_sleep(start); //busy wait
        
        QueryPerformanceCounter(&start);    
        
        /* call tick function */
        sKey = GetAsyncKeyState(S_KEY);
        rKey = GetAsyncKeyState(R_KEY); 
        blc_blech_stopwatchLAPFAST_tick(ONE & sKey,ONE & rKey);
    }
    
    return 0; /* OK */
}