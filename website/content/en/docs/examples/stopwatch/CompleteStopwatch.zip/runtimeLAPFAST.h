#ifndef RUNTIMELAPFAST_H_INCLUDED
#define RUNTIMELAPFAST_H_INCLUDED

void showConsole (const struct blc_stopwatchLAPFAST_Display *const blc_this);

#endif